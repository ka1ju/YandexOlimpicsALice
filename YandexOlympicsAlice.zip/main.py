from flask import Flask, request
import logging
import json
from funcs import out
from oleg import *
from all_wallets import *

app = Flask(__name__)

logging.basicConfig(level=logging.INFO)


@app.route('/', methods=['POST'])
def main():
    logging.info(f'Request: {request.json!r}')

    response = {
        'session': request.json['session'],
        'version': request.json['version'],
        'response': {
            'end_session': False
        }
    }

    handle_dialog(request.json, response)
    logging.info(f'Response:  {response!r}')
    return json.dumps(response)


def handle_dialog(req, res):
    user_id = req['session']['user_id']
    user_message = req['request']['command'].lower()

    if req['session']['new']:
        res['response']['text'] = authorization(user_id)
        logging.info("Authorising user")
        return

    if ('созд' in user_message or 'доб' in user_message) and \
            ('кошел' in user_message or 'счёт' in user_message):
        res['response']['text'] = "Хорошо, создадим кошелёк"
        logging.info("Adding wallet")
        return

    if ('удал' in user_message or 'убр' in user_message) and \
            ('кошел' in user_message or 'счёт' in user_message):
        res['response']['text'] = "Подтвердите удаление кошелька"
        logging.info("Deleting wallet")
        return

    if ('пополн' in user_message or 'зачисл' in user_message) and \
            ('кошел' in user_message or 'счёт' in user_message):
        res['response']['text'] = "Пополнил кошелёк"
        logging.info("Adding money")
        return

    if ('трат' in user_message or 'сн' in user_message) and \
            ('кошел' in user_message or 'счёт' in user_message):
        res['response']['text'] = "Снял с кошелька"
        logging.info("Spending money")
        return

    if ('выв' in user_message or 'дай' in user_message or 'ска' in user_message) and \
            'инф' in user_message and \
            ('кошел' in user_message or 'счёт' in user_message):
        res['response']['text'] = "Вывел информацию о счёте"
        logging.info("Giving info about wallet")
        return

    if ('выв' in user_message or 'дай' in user_message or 'ска' in user_message) and \
            'стат' in user_message:
        res['response']['text'] = "Вывел статистику"
        logging.info("Giving statics about expenses")
        return

    if ('выв' in user_message or 'дай' in user_message or 'ска' in user_message) and \
            ('кошел' in user_message or 'счёт' in user_message):
        res['response']['text'] = "Вывел кошельки"
        logging.info("Giving all wallets")
        print(return_wallets())
        return

    res['response']['text'] = "Извините, я Вас не понял."


if __name__ == '__main__':
    app.run(port=5000)

# C:\Users\Administrator\Desktop\ngrok http 5000
